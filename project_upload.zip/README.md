# FINANSE MAGAZYNU — Cashflow Core v1

Webowa aplikacja zarządcza (controlling) dla jednoosobowej działalności gospodarczej.
Pozwala w jednym miejscu śledzić przychody, koszty stałe i zmienne, VAT, ZUS, PIT oraz prognozę netto właściciela.

## Stack

- **Next.js 16** (App Router) + TypeScript
- **Tailwind CSS 4** (ciemny motyw, mobile-first)
- **Supabase** (Postgres + Auth)
- **Prisma** (ORM, migracje)
- **Vercel** (deploy + cron)

## Wymagania

- Node.js 20+
- Konto Supabase (darmowe wystarczy)
- (Opcjonalnie) Konto Vercel do deployu

## Uruchomienie lokalne

### 1. Klonowanie i instalacja

```bash
git clone <repo-url>
cd finanse-magazynu
npm install
```

### 2. Konfiguracja Supabase

1. Utwórz projekt na [supabase.com](https://supabase.com)
2. W ustawieniach projektu znajdź:
   - Project URL → `NEXT_PUBLIC_SUPABASE_URL`
   - Anon public key → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - Service role key → `SUPABASE_SERVICE_ROLE_KEY`
   - Database → Connection string (URI) → `DATABASE_URL`
3. W Authentication → Settings:
   - Wyłącz email confirmation (dla wygody w MVP): `Enable email confirmations` = OFF

### 3. Zmienne środowiskowe

Skopiuj plik przykładowy i uzupełnij:

```bash
cp .env.local.example .env.local
```

Wypełnij `.env.local`:

```
NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
SUPABASE_SERVICE_ROLE_KEY=eyJ...
DATABASE_URL=postgresql://postgres:password@db.xxx.supabase.co:5432/postgres
CRON_SECRET=losowy-token-min-32-znaki
NEXT_PUBLIC_APP_NAME=FINANSE MAGAZYNU
```

### 4. Migracja bazy danych

```bash
npx prisma db push
npx prisma generate
```

### 5. Seed danych (kategorie + reguły recurring)

```bash
npm run db:seed
```

### 6. Uruchomienie dev

```bash
npm run dev
```

Otwórz http://localhost:3000. Utwórz konto (email + hasło min. 6 znaków).

## Deploy na Vercel

### 1. Push do GitHub

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <repo-url>
git push -u origin main
```

### 2. Import w Vercel

1. Zaloguj się na [vercel.com](https://vercel.com)
2. Import project z GitHub
3. Dodaj zmienne środowiskowe (Environment Variables):
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `DATABASE_URL`
   - `CRON_SECRET`
   - `NEXT_PUBLIC_APP_NAME`
4. Deploy

### 3. Cron (generowanie kosztów stałych)

Plik `vercel.json` zawiera konfigurację crona:

```json
{
  "crons": [{
    "path": "/api/cron/generate-recurring",
    "schedule": "0 2 * * *"
  }]
}
```

Cron uruchomi się codziennie o 02:00 UTC (ok. 03:00-04:00 CET).
Endpoint wymaga nagłówka `Authorization: Bearer <CRON_SECRET>`.
Vercel automatycznie dodaje ten nagłówek.

## Struktura projektu

```
src/
├── app/
│   ├── (authenticated)/     # Chronione strony z nawigacją
│   │   ├── dashboard/       # Dashboard MÓJ WYNIK
│   │   ├── transactions/    # Lista i dodawanie transakcji
│   │   ├── recurring/       # Koszty stałe (reguły)
│   │   └── months/          # Miesiące (parametry, zamknięcie)
│   ├── login/               # Logowanie
│   └── api/                 # API routes
├── components/              # Współdzielone komponenty UI
└── lib/                     # Logika: obliczenia, DB, auth, walidacja
prisma/
└── schema.prisma            # Model danych
scripts/
└── seed.ts                  # Seed kategorii i reguł
```

## Env vars

| Zmienna | Opis |
|---------|------|
| `NEXT_PUBLIC_SUPABASE_URL` | URL projektu Supabase |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Klucz anonimowy Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | Klucz service role (dla cron) |
| `DATABASE_URL` | Connection string do Postgres |
| `CRON_SECRET` | Token autoryzacji crona |
| `NEXT_PUBLIC_APP_NAME` | Nazwa wyświetlana w UI |

## Znane ograniczenia MVP

- **Single-user**: brak ról, brak blokady rejestracji wielu kont (Supabase Auth pozwala na rejestrację — w produkcji wyłącz sign-up po utworzeniu konta)
- **Brak importu z banku** — wszystko wpisywane ręcznie
- **Brak uploadu plików** — pole attachmentUrl w modelu, ale brak UI
- **Brak multi-currency** — tylko PLN
- **Brak JPK / compliance** — to narzędzie zarządcze, nie księgowość
- **VAT uproszczony** — metoda kasowa, bez korekt okresowych
- **Cron wymaga Vercel** — na VPS: użyj systemowego crontab z `curl`
