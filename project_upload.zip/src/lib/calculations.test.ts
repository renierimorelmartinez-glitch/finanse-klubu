import { calculateNet, calculateVat, computeMonthSummary } from "./calculations";

describe("calculateNet", () => {
  it("calculates net from gross with 23% VAT", () => {
    expect(calculateNet(123, 23)).toBe(100);
  });

  it("calculates net from gross with 8% VAT", () => {
    expect(calculateNet(108, 8)).toBe(100);
  });

  it("returns gross when VAT is 0%", () => {
    expect(calculateNet(100, 0)).toBe(100);
  });

  it("handles decimal amounts", () => {
    expect(calculateNet(7200, 23)).toBe(5853.66);
  });
});

describe("calculateVat", () => {
  it("calculates VAT from gross with 23%", () => {
    expect(calculateVat(123, 23)).toBe(23);
  });

  it("calculates VAT from gross with 8%", () => {
    expect(calculateVat(108, 8)).toBe(8);
  });

  it("returns 0 when VAT is 0%", () => {
    expect(calculateVat(100, 0)).toBe(0);
  });

  it("handles large amounts", () => {
    expect(calculateVat(7200, 23)).toBe(1346.34);
  });
});

describe("computeMonthSummary", () => {
  it("computes correct summary with income and expenses", () => {
    const transactions = [
      { type: "INCOME", grossAmount: 10000, vatAmount: 1869.92 },
      { type: "INCOME", grossAmount: 5000, vatAmount: 934.96 },
      { type: "EXPENSE", grossAmount: 7200, vatAmount: 1346.34 },
      { type: "EXPENSE", grossAmount: 300, vatAmount: 56.10 },
    ];

    const params = {
      zusAmount: 1600,
      pitAmount: 500,
      vatAdjustmentAmount: 0,
    };

    const result = computeMonthSummary(transactions, params);

    expect(result.totalIncomeGross).toBe(15000);
    expect(result.totalExpenseGross).toBe(7500);
    expect(result.operatingResult).toBe(7500);
    expect(result.vatDue).toBeCloseTo(2804.88, 1);
    expect(result.vatInput).toBeCloseTo(1402.44, 1);
    expect(result.vatToPay).toBeCloseTo(1402.44, 1);
    expect(result.netForecast).toBeCloseTo(3997.56, 0);
  });

  it("handles negative VAT (surplus)", () => {
    const transactions = [
      { type: "INCOME", grossAmount: 1000, vatAmount: 74.07 },
      { type: "EXPENSE", grossAmount: 7200, vatAmount: 1346.34 },
    ];

    const params = { zusAmount: 0, pitAmount: 0, vatAdjustmentAmount: 0 };
    const result = computeMonthSummary(transactions, params);

    expect(result.vatToPay).toBeLessThan(0);
    // When vatToPay < 0, netForecast uses max(vatToPay, 0) = 0
    expect(result.netForecast).toBe(result.operatingResult);
  });

  it("handles empty transactions", () => {
    const result = computeMonthSummary([], {
      zusAmount: 1600,
      pitAmount: 500,
      vatAdjustmentAmount: 0,
    });

    expect(result.totalIncomeGross).toBe(0);
    expect(result.totalExpenseGross).toBe(0);
    expect(result.operatingResult).toBe(0);
    expect(result.netForecast).toBe(-2100);
  });
});
