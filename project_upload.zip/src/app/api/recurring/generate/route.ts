import { prisma } from "@/lib/prisma";
import { createClient } from "@/lib/supabase/server";
import { calculateNet, calculateVat } from "@/lib/calculations";
import { getCurrentMonth } from "@/lib/month-utils";
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await request.json().catch(() => ({}));
  const month = body.month || getCurrentMonth();

  const result = await generateRecurringForMonth(month);
  return NextResponse.json(result);
}

export async function generateRecurringForMonth(month: string) {
  // Check if month is closed
  const monthParams = await prisma.monthParams.findUnique({ where: { month } });
  if (monthParams?.status === "CLOSED") {
    return { generated: 0, message: "Miesiąc zamknięty" };
  }

  const rules = await prisma.recurringRule.findMany({
    where: { isActive: true },
  });

  let generated = 0;

  for (const rule of rules) {
    // Check if rule applies to this month
    if (rule.startMonth > month) continue;
    if (rule.endMonth && rule.endMonth < month) continue;

    // Check idempotency: already generated?
    const existing = await prisma.transaction.findFirst({
      where: {
        generatedFromRecurringRuleId: rule.id,
        month,
      },
    });

    if (existing) continue;

    const [yearStr, monthStr] = month.split("-");
    const year = parseInt(yearStr, 10);
    const mon = parseInt(monthStr, 10);
    const day = Math.min(rule.dayOfMonth, new Date(year, mon, 0).getDate());
    const occurredAt = new Date(year, mon - 1, day);

    const grossAmount = Number(rule.grossAmount);
    const netAmount = calculateNet(grossAmount, rule.vatRate);
    const vatAmount = calculateVat(grossAmount, rule.vatRate);

    await prisma.transaction.create({
      data: {
        type: "EXPENSE",
        categoryId: rule.categoryId,
        grossAmount,
        vatRate: rule.vatRate,
        netAmount,
        vatAmount,
        occurredAt,
        month,
        note: `Auto: ${rule.name}`,
        generatedFromRecurringRuleId: rule.id,
      },
    });

    generated++;
  }

  return { generated, month };
}
