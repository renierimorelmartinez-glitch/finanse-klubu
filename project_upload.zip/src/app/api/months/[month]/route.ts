import { prisma } from "@/lib/prisma";
import { createClient } from "@/lib/supabase/server";
import { monthParamsSchema } from "@/lib/validations";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ month: string }> }
) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { month } = await params;

  let monthParams = await prisma.monthParams.findUnique({ where: { month } });
  if (!monthParams) {
    monthParams = await prisma.monthParams.create({
      data: { month },
    });
  }

  return NextResponse.json(monthParams);
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ month: string }> }
) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { month } = await params;
  const body = await request.json();
  const parsed = monthParamsSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }

  const monthParams = await prisma.monthParams.upsert({
    where: { month },
    update: parsed.data,
    create: { month, ...parsed.data },
  });

  return NextResponse.json(monthParams);
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ month: string }> }
) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { month } = await params;
  const body = await request.json();

  if (body.action === "close") {
    // Lock all transactions in this month
    await prisma.transaction.updateMany({
      where: { month },
      data: { isLocked: true },
    });

    const monthParams = await prisma.monthParams.upsert({
      where: { month },
      update: { status: "CLOSED", closedAt: new Date() },
      create: { month, status: "CLOSED", closedAt: new Date() },
    });

    return NextResponse.json(monthParams);
  }

  if (body.action === "reopen") {
    await prisma.transaction.updateMany({
      where: { month },
      data: { isLocked: false },
    });

    const monthParams = await prisma.monthParams.update({
      where: { month },
      data: { status: "OPEN", closedAt: null },
    });

    return NextResponse.json(monthParams);
  }

  return NextResponse.json({ error: "Unknown action" }, { status: 400 });
}
