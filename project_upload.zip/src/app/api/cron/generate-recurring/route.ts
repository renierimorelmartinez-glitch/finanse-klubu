import { NextRequest, NextResponse } from "next/server";
import { generateRecurringForMonth } from "@/app/api/recurring/generate/route";
import { getCurrentMonth } from "@/lib/month-utils";

export async function GET(request: NextRequest) {
  // Verify cron secret
  const authHeader = request.headers.get("authorization");
  const cronSecret = process.env.CRON_SECRET;

  if (!cronSecret || authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const month = getCurrentMonth();
  const result = await generateRecurringForMonth(month);

  return NextResponse.json(result);
}
