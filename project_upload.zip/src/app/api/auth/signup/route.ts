import { createClient } from "@/lib/supabase/server";
import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  const { email, password } = await request.json();

  // Single-user guard: check if any user exists via Supabase admin
  // We use a simple approach: check if we can list auth users
  // For MVP, we'll check by counting existing month_params or use a flag
  const supabase = await createClient();

  // Try to sign up
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 400 });
  }

  return NextResponse.json({ user: data.user });
}
