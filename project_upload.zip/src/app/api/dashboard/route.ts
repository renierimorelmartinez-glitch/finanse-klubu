import { prisma } from "@/lib/prisma";
import { createClient } from "@/lib/supabase/server";
import { computeMonthSummary } from "@/lib/calculations";
import { NextRequest, NextResponse } from "next/server";

export async function GET(request: NextRequest) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { searchParams } = new URL(request.url);
  const month = searchParams.get("month");
  if (!month) {
    return NextResponse.json({ error: "month parameter required" }, { status: 400 });
  }

  // Get or create month params
  let monthParams = await prisma.monthParams.findUnique({ where: { month } });
  if (!monthParams) {
    monthParams = await prisma.monthParams.create({ data: { month } });
  }

  // Get all transactions for this month
  const transactions = await prisma.transaction.findMany({
    where: { month },
    include: { category: true },
  });

  const summary = computeMonthSummary(transactions, {
    zusAmount: Number(monthParams.zusAmount),
    pitAmount: Number(monthParams.pitAmount),
    vatAdjustmentAmount: Number(monthParams.vatAdjustmentAmount),
  });

  // Category breakdown
  const incomeByCategory: Record<string, { name: string; gross: number }> = {};
  const expenseByCategory: Record<string, { name: string; gross: number; isFixed: boolean }> = {};

  for (const t of transactions) {
    const gross = Number(t.grossAmount);
    if (t.type === "INCOME") {
      if (!incomeByCategory[t.categoryId]) {
        incomeByCategory[t.categoryId] = { name: t.category.name, gross: 0 };
      }
      incomeByCategory[t.categoryId].gross += gross;
    } else {
      if (!expenseByCategory[t.categoryId]) {
        expenseByCategory[t.categoryId] = {
          name: t.category.name,
          gross: 0,
          isFixed: !!t.generatedFromRecurringRuleId,
        };
      }
      expenseByCategory[t.categoryId].gross += gross;
    }
  }

  // Fixed vs variable expenses
  let fixedExpenses = 0;
  let variableExpenses = 0;
  for (const t of transactions) {
    if (t.type === "EXPENSE") {
      if (t.generatedFromRecurringRuleId) {
        fixedExpenses += Number(t.grossAmount);
      } else {
        variableExpenses += Number(t.grossAmount);
      }
    }
  }

  return NextResponse.json({
    summary,
    monthParams: {
      ...monthParams,
      zusAmount: Number(monthParams.zusAmount),
      pitAmount: Number(monthParams.pitAmount),
      vatAdjustmentAmount: Number(monthParams.vatAdjustmentAmount),
    },
    incomeByCategory: Object.values(incomeByCategory),
    expenseByCategory: Object.values(expenseByCategory),
    fixedExpenses: Math.round(fixedExpenses * 100) / 100,
    variableExpenses: Math.round(variableExpenses * 100) / 100,
  });
}
