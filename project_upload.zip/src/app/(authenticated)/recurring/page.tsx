"use client";

import { useEffect, useState } from "react";
import { getCurrentMonth } from "@/lib/month-utils";

interface Category {
  id: string;
  name: string;
  defaultVatRate: number;
}

interface RecurringRule {
  id: string;
  name: string;
  categoryId: string;
  grossAmount: string;
  vatRate: number;
  dayOfMonth: number;
  isActive: boolean;
  startMonth: string;
  endMonth: string | null;
  category: { name: string };
}

function formatPLN(amount: number): string {
  return new Intl.NumberFormat("pl-PL", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export default function RecurringPage() {
  const [rules, setRules] = useState<RecurringRule[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [genMessage, setGenMessage] = useState("");

  // Form state
  const [name, setName] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [grossAmount, setGrossAmount] = useState("");
  const [vatRate, setVatRate] = useState(23);
  const [dayOfMonth, setDayOfMonth] = useState(1);
  const [startMonth, setStartMonth] = useState(getCurrentMonth());
  const [editingId, setEditingId] = useState<string | null>(null);
  const [error, setError] = useState("");

  const fetchData = async () => {
    setLoading(true);
    const [rulesRes, catsRes] = await Promise.all([
      fetch("/api/recurring"),
      fetch("/api/categories?type=EXPENSE"),
    ]);
    setRules(await rulesRes.json());
    setCategories(await catsRes.json());
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const resetForm = () => {
    setName("");
    setCategoryId("");
    setGrossAmount("");
    setVatRate(23);
    setDayOfMonth(1);
    setStartMonth(getCurrentMonth());
    setEditingId(null);
    setError("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    const body = {
      name,
      categoryId,
      grossAmount: parseFloat(grossAmount),
      vatRate,
      dayOfMonth,
      isActive: true,
      startMonth,
      endMonth: null,
    };

    const url = editingId ? `/api/recurring/${editingId}` : "/api/recurring";
    const method = editingId ? "PUT" : "POST";

    const res = await fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const data = await res.json();
      setError(JSON.stringify(data.error));
      return;
    }

    resetForm();
    setShowForm(false);
    fetchData();
  };

  const handleEdit = (rule: RecurringRule) => {
    setEditingId(rule.id);
    setName(rule.name);
    setCategoryId(rule.categoryId);
    setGrossAmount(String(rule.grossAmount));
    setVatRate(rule.vatRate);
    setDayOfMonth(rule.dayOfMonth);
    setStartMonth(rule.startMonth);
    setShowForm(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Usunąć regułę?")) return;
    await fetch(`/api/recurring/${id}`, { method: "DELETE" });
    fetchData();
  };

  const handleGenerate = async () => {
    setGenerating(true);
    setGenMessage("");
    const res = await fetch("/api/recurring/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ month: getCurrentMonth() }),
    });
    const data = await res.json();
    setGenMessage(`Wygenerowano ${data.generated} transakcji dla ${data.month}`);
    setGenerating(false);
  };

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Koszty stałe (recurring)</h2>
      </div>

      {/* Generate button */}
      <div className="flex gap-2">
        <button
          onClick={handleGenerate}
          disabled={generating}
          className="flex-1 py-2 bg-info/20 hover:bg-info/30 text-info font-medium rounded-lg text-sm transition-colors disabled:opacity-50"
        >
          {generating ? "Generuję..." : "Wygeneruj dla bieżącego miesiąca"}
        </button>
        <button
          onClick={() => {
            resetForm();
            setShowForm(!showForm);
          }}
          className="px-4 py-2 bg-accent hover:bg-accent-hover text-bg-primary font-medium rounded-lg text-sm transition-colors"
        >
          {showForm ? "Anuluj" : "+ Dodaj"}
        </button>
      </div>

      {genMessage && (
        <p className="text-sm text-income bg-income/10 rounded-lg p-2">
          {genMessage}
        </p>
      )}

      {/* Form */}
      {showForm && (
        <form
          onSubmit={handleSubmit}
          className="bg-bg-card rounded-xl p-4 border border-border space-y-3"
        >
          <div>
            <label className="block text-xs text-text-secondary mb-1 uppercase tracking-wide">
              Nazwa
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              placeholder="np. Czynsz"
            />
          </div>
          <div>
            <label className="block text-xs text-text-secondary mb-1 uppercase tracking-wide">
              Kategoria
            </label>
            <select
              value={categoryId}
              onChange={(e) => {
                setCategoryId(e.target.value);
                const cat = categories.find((c) => c.id === e.target.value);
                if (cat) setVatRate(cat.defaultVatRate);
              }}
              required
            >
              <option value="">Wybierz</option>
              {categories.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name}
                </option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-text-secondary mb-1 uppercase tracking-wide">
                Kwota brutto
              </label>
              <input
                type="number"
                step="0.01"
                min="0.01"
                value={grossAmount}
                onChange={(e) => setGrossAmount(e.target.value)}
                required
              />
            </div>
            <div>
              <label className="block text-xs text-text-secondary mb-1 uppercase tracking-wide">
                VAT %
              </label>
              <select value={vatRate} onChange={(e) => setVatRate(Number(e.target.value))}>
                <option value={0}>0%</option>
                <option value={8}>8%</option>
                <option value={23}>23%</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs text-text-secondary mb-1 uppercase tracking-wide">
                Dzień miesiąca
              </label>
              <input
                type="number"
                min="1"
                max="31"
                value={dayOfMonth}
                onChange={(e) => setDayOfMonth(Number(e.target.value))}
                required
              />
            </div>
            <div>
              <label className="block text-xs text-text-secondary mb-1 uppercase tracking-wide">
                Od miesiąca
              </label>
              <input
                type="month"
                value={startMonth}
                onChange={(e) => setStartMonth(e.target.value)}
                required
              />
            </div>
          </div>
          {error && <p className="text-expense text-sm">{error}</p>}
          <button
            type="submit"
            className="w-full py-2 bg-accent hover:bg-accent-hover text-bg-primary font-semibold rounded-lg text-sm transition-colors"
          >
            {editingId ? "Zapisz zmiany" : "Dodaj regułę"}
          </button>
        </form>
      )}

      {/* List */}
      {loading ? (
        <div className="text-center text-text-muted py-8">Ładowanie...</div>
      ) : rules.length === 0 ? (
        <div className="text-center text-text-muted py-8">Brak reguł</div>
      ) : (
        <div className="space-y-2">
          {rules.map((rule) => (
            <div
              key={rule.id}
              className="bg-bg-card rounded-xl p-4 border border-border"
            >
              <div className="flex items-center justify-between mb-1">
                <span className="font-medium text-sm">{rule.name}</span>
                <span className="text-base font-bold tabular-nums text-expense">
                  {formatPLN(Number(rule.grossAmount))} zł
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="text-xs text-text-muted">
                  {rule.category.name} · VAT {rule.vatRate}% · dzień {rule.dayOfMonth} · od{" "}
                  {rule.startMonth}
                  {!rule.isActive && (
                    <span className="ml-1 text-expense">nieaktywna</span>
                  )}
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEdit(rule)}
                    className="text-xs text-text-muted hover:text-accent"
                  >
                    Edytuj
                  </button>
                  <button
                    onClick={() => handleDelete(rule.id)}
                    className="text-xs text-text-muted hover:text-expense"
                  >
                    Usuń
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
