"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { getCurrentMonth, formatMonthLabel } from "@/lib/month-utils";
import MonthSelector from "@/components/MonthSelector";
import Link from "next/link";

interface Transaction {
  id: string;
  type: "INCOME" | "EXPENSE";
  grossAmount: string;
  vatRate: number;
  occurredAt: string;
  month: string;
  note: string | null;
  isLocked: boolean;
  generatedFromRecurringRuleId: string | null;
  category: { name: string };
}

function formatPLN(amount: number): string {
  return new Intl.NumberFormat("pl-PL", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export default function TransactionsPage() {
  return (
    <Suspense fallback={<div className="p-4 text-center text-text-muted">Ładowanie...</div>}>
      <TransactionsContent />
    </Suspense>
  );
}

function TransactionsContent() {
  const searchParams = useSearchParams();
  const month = searchParams.get("month") || getCurrentMonth();
  const typeFilter = searchParams.get("type") || "";
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = () => {
    setLoading(true);
    const params = new URLSearchParams({ month });
    if (typeFilter) params.set("type", typeFilter);
    fetch(`/api/transactions?${params}`)
      .then((r) => r.json())
      .then((d) => {
        setTransactions(d);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchData();
  }, [month, typeFilter]);

  const handleDelete = async (id: string) => {
    if (!confirm("Usunąć transakcję?")) return;
    await fetch(`/api/transactions/${id}`, { method: "DELETE" });
    fetchData();
  };

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold">Transakcje</h2>
        <MonthSelector currentMonth={month} basePath="/transactions" />
      </div>

      {/* Filters */}
      <div className="flex gap-2">
        {[
          { value: "", label: "Wszystkie" },
          { value: "INCOME", label: "Przychody" },
          { value: "EXPENSE", label: "Koszty" },
        ].map(({ value, label }) => (
          <Link
            key={value}
            href={`/transactions?month=${month}${value ? `&type=${value}` : ""}`}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
              typeFilter === value
                ? "bg-accent text-bg-primary"
                : "bg-bg-card text-text-secondary hover:bg-bg-hover"
            }`}
          >
            {label}
          </Link>
        ))}
      </div>

      {/* Add button */}
      <Link
        href={`/transactions/new?month=${month}`}
        className="block w-full py-3 bg-accent hover:bg-accent-hover text-bg-primary font-semibold rounded-lg text-center text-sm transition-colors"
      >
        + Dodaj transakcję
      </Link>

      {/* List */}
      {loading ? (
        <div className="text-center text-text-muted py-8">Ładowanie...</div>
      ) : transactions.length === 0 ? (
        <div className="text-center text-text-muted py-8">
          Brak transakcji w tym miesiącu
        </div>
      ) : (
        <div className="space-y-2">
          {transactions.map((t) => (
            <div
              key={t.id}
              className="bg-bg-card rounded-xl p-4 border border-border flex items-center justify-between"
            >
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span
                    className={`text-xs font-medium px-1.5 py-0.5 rounded ${
                      t.type === "INCOME"
                        ? "bg-income/20 text-income"
                        : "bg-expense/20 text-expense"
                    }`}
                  >
                    {t.type === "INCOME" ? "P" : "K"}
                  </span>
                  <span className="text-sm font-medium truncate">
                    {t.category.name}
                  </span>
                  {t.generatedFromRecurringRuleId && (
                    <span className="text-xs text-text-muted">🔄</span>
                  )}
                  {t.isLocked && (
                    <span className="text-xs text-text-muted">🔒</span>
                  )}
                </div>
                <div className="flex items-center gap-2 text-xs text-text-muted">
                  <span>{new Date(t.occurredAt).toLocaleDateString("pl-PL")}</span>
                  <span>VAT {t.vatRate}%</span>
                  {t.note && <span className="truncate">{t.note}</span>}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span
                  className={`text-base font-bold tabular-nums ${
                    t.type === "INCOME" ? "text-income" : "text-expense"
                  }`}
                >
                  {t.type === "INCOME" ? "+" : "-"}
                  {formatPLN(Number(t.grossAmount))}
                </span>
                {!t.isLocked && (
                  <button
                    onClick={() => handleDelete(t.id)}
                    className="text-text-muted hover:text-expense text-xs"
                  >
                    ✕
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
