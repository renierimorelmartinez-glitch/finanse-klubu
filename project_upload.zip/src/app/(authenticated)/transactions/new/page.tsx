"use client";

import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { getCurrentMonth } from "@/lib/month-utils";

interface Category {
  id: string;
  name: string;
  type: "INCOME" | "EXPENSE";
  defaultVatRate: number;
  isFrequent: boolean;
}

export default function NewTransactionPage() {
  return (
    <Suspense fallback={<div className="p-4 text-text-muted">Ładowanie...</div>}>
      <NewTransactionForm />
    </Suspense>
  );
}

function NewTransactionForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const typeParam = searchParams.get("type") as "INCOME" | "EXPENSE" | null;
  const monthParam = searchParams.get("month") || getCurrentMonth();

  const [type, setType] = useState<"INCOME" | "EXPENSE">(typeParam || "INCOME");
  const [categories, setCategories] = useState<Category[]>([]);
  const [categoryId, setCategoryId] = useState("");
  const [grossAmount, setGrossAmount] = useState("");
  const [vatRate, setVatRate] = useState(23);
  const [occurredAt, setOccurredAt] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetch(`/api/categories?type=${type}`)
      .then((r) => r.json())
      .then((cats: Category[]) => {
        setCategories(cats);
        if (cats.length > 0 && !categoryId) {
          const freq = cats.find((c) => c.isFrequent);
          const first = freq || cats[0];
          setCategoryId(first.id);
          setVatRate(first.defaultVatRate);
        }
      });
  }, [type]);

  const handleCategoryChange = (id: string) => {
    setCategoryId(id);
    const cat = categories.find((c) => c.id === id);
    if (cat) setVatRate(cat.defaultVatRate);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSaving(true);

    const res = await fetch("/api/transactions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        type,
        categoryId,
        grossAmount: parseFloat(grossAmount),
        vatRate,
        occurredAt,
        note: note || undefined,
      }),
    });

    if (!res.ok) {
      const data = await res.json();
      setError(data.error?.formErrors?.[0] || data.error || "Błąd zapisu");
      setSaving(false);
      return;
    }

    router.push(`/transactions?month=${monthParam}`);
  };

  return (
    <div className="max-w-lg mx-auto p-4">
      <h2 className="text-lg font-semibold mb-4">Nowa transakcja</h2>

      {/* Type toggle */}
      <div className="flex gap-2 mb-4">
        <button
          onClick={() => { setType("INCOME"); setCategoryId(""); }}
          className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-colors ${
            type === "INCOME"
              ? "bg-income text-white"
              : "bg-bg-card text-text-secondary"
          }`}
        >
          Przychód
        </button>
        <button
          onClick={() => { setType("EXPENSE"); setCategoryId(""); }}
          className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-colors ${
            type === "EXPENSE"
              ? "bg-expense text-white"
              : "bg-bg-card text-text-secondary"
          }`}
        >
          Koszt
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Quick categories */}
        {categories.filter((c) => c.isFrequent).length > 0 && (
          <div>
            <label className="block text-xs text-text-secondary mb-2 uppercase tracking-wide">
              Szybki wybór
            </label>
            <div className="flex flex-wrap gap-2">
              {categories
                .filter((c) => c.isFrequent)
                .map((cat) => (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => handleCategoryChange(cat.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      categoryId === cat.id
                        ? "bg-accent text-bg-primary"
                        : "bg-bg-card text-text-secondary hover:bg-bg-hover"
                    }`}
                  >
                    {cat.name}
                  </button>
                ))}
            </div>
          </div>
        )}

        {/* Category select */}
        <div>
          <label className="block text-xs text-text-secondary mb-1.5 uppercase tracking-wide">
            Kategoria
          </label>
          <select
            value={categoryId}
            onChange={(e) => handleCategoryChange(e.target.value)}
            required
          >
            <option value="">Wybierz kategorię</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.name} (VAT {cat.defaultVatRate}%)
              </option>
            ))}
          </select>
        </div>

        {/* Amount */}
        <div>
          <label className="block text-xs text-text-secondary mb-1.5 uppercase tracking-wide">
            Kwota brutto (zł)
          </label>
          <input
            type="number"
            step="0.01"
            min="0.01"
            value={grossAmount}
            onChange={(e) => setGrossAmount(e.target.value)}
            required
            placeholder="0.00"
            className="text-2xl font-bold"
            autoFocus
          />
        </div>

        {/* VAT */}
        <div>
          <label className="block text-xs text-text-secondary mb-1.5 uppercase tracking-wide">
            Stawka VAT
          </label>
          <div className="flex gap-2">
            {[0, 8, 23].map((rate) => (
              <button
                key={rate}
                type="button"
                onClick={() => setVatRate(rate)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium transition-colors ${
                  vatRate === rate
                    ? "bg-accent text-bg-primary"
                    : "bg-bg-card text-text-secondary hover:bg-bg-hover"
                }`}
              >
                {rate}%
              </button>
            ))}
          </div>
        </div>

        {/* Date */}
        <div>
          <label className="block text-xs text-text-secondary mb-1.5 uppercase tracking-wide">
            Data
          </label>
          <input
            type="date"
            value={occurredAt}
            onChange={(e) => setOccurredAt(e.target.value)}
            required
          />
        </div>

        {/* Note */}
        <div>
          <label className="block text-xs text-text-secondary mb-1.5 uppercase tracking-wide">
            Notatka (opcjonalnie)
          </label>
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="np. nazwa klienta"
          />
        </div>

        {error && <p className="text-expense text-sm">{error}</p>}

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3 bg-accent hover:bg-accent-hover text-bg-primary font-semibold rounded-lg transition-colors disabled:opacity-50"
        >
          {saving ? "Zapisuję..." : "Zapisz"}
        </button>

        <button
          type="button"
          onClick={() => router.back()}
          className="w-full py-2 text-text-muted hover:text-text-secondary text-sm transition-colors"
        >
          Anuluj
        </button>
      </form>
    </div>
  );
}
