"use client";

import { Suspense, useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";
import { getCurrentMonth, formatMonthLabel } from "@/lib/month-utils";
import MonthSelector from "@/components/MonthSelector";
import Link from "next/link";

interface DashboardData {
  summary: {
    totalIncomeGross: number;
    totalExpenseGross: number;
    operatingResult: number;
    vatDue: number;
    vatInput: number;
    vatToPay: number;
    zusAmount: number;
    pitAmount: number;
    netForecast: number;
  };
  monthParams: {
    status: string;
  };
  incomeByCategory: Array<{ name: string; gross: number }>;
  expenseByCategory: Array<{ name: string; gross: number; isFixed: boolean }>;
  fixedExpenses: number;
  variableExpenses: number;
}

function formatPLN(amount: number): string {
  return new Intl.NumberFormat("pl-PL", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export default function DashboardPage() {
  return (
    <Suspense fallback={<div className="flex items-center justify-center h-64 text-text-muted">Ładowanie...</div>}>
      <DashboardContent />
    </Suspense>
  );
}

function DashboardContent() {
  const searchParams = useSearchParams();
  const month = searchParams.get("month") || getCurrentMonth();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    fetch(`/api/dashboard?month=${month}`)
      .then((r) => r.json())
      .then((d) => {
        setData(d);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, [month]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-text-muted">Ładowanie...</div>
      </div>
    );
  }

  if (!data || !data.summary) {
    return (
      <div className="p-4 text-center text-text-secondary">
        Brak danych dla tego miesiąca
      </div>
    );
  }

  const { summary } = data;
  const isClosed = data.monthParams.status === "CLOSED";

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">MÓJ WYNIK</h2>
          <p className="text-text-secondary text-sm">{formatMonthLabel(month)}</p>
        </div>
        <div className="flex items-center gap-2">
          {isClosed && (
            <span className="text-xs px-2 py-1 bg-income/20 text-income rounded">
              ZAMKNIĘTY
            </span>
          )}
          <MonthSelector currentMonth={month} basePath="/dashboard" />
        </div>
      </div>

      {/* Hero: Net Forecast */}
      <div className="bg-bg-card rounded-xl p-6 border border-border text-center">
        <p className="text-xs text-text-muted uppercase tracking-wider mb-1">
          Prognoza netto właściciela
        </p>
        <p
          className={`text-4xl md:text-5xl font-bold tabular-nums ${
            summary.netForecast >= 0 ? "text-income" : "text-expense"
          }`}
        >
          {formatPLN(summary.netForecast)} zł
        </p>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-2 gap-3">
        <KPICard
          label="Przychody"
          value={summary.totalIncomeGross}
          color="text-income"
        />
        <KPICard
          label="Koszty"
          value={summary.totalExpenseGross}
          color="text-expense"
        />
        <KPICard
          label="Wynik operacyjny"
          value={summary.operatingResult}
          color={summary.operatingResult >= 0 ? "text-income" : "text-expense"}
        />
        <KPICard
          label={summary.vatToPay >= 0 ? "VAT do zapłaty" : "Nadwyżka VAT"}
          value={Math.abs(summary.vatToPay)}
          color={summary.vatToPay > 0 ? "text-warning" : "text-info"}
        />
        <KPICard label="ZUS" value={summary.zusAmount} color="text-text-primary" />
        <KPICard label="PIT" value={summary.pitAmount} color="text-text-primary" />
      </div>

      {/* Quick Add */}
      <div className="flex gap-3">
        <Link
          href={`/transactions/new?type=INCOME&month=${month}`}
          className="flex-1 py-3 bg-income/20 hover:bg-income/30 text-income font-semibold rounded-lg text-center text-sm transition-colors"
        >
          + Przychód
        </Link>
        <Link
          href={`/transactions/new?type=EXPENSE&month=${month}`}
          className="flex-1 py-3 bg-expense/20 hover:bg-expense/30 text-expense font-semibold rounded-lg text-center text-sm transition-colors"
        >
          + Koszt
        </Link>
      </div>

      {/* Income breakdown */}
      {data.incomeByCategory.length > 0 && (
        <div className="bg-bg-card rounded-xl p-4 border border-border">
          <h3 className="text-sm font-semibold text-text-secondary mb-3 uppercase tracking-wide">
            Przychody wg kategorii
          </h3>
          <div className="space-y-2">
            {data.incomeByCategory
              .sort((a, b) => b.gross - a.gross)
              .map((cat) => (
                <div key={cat.name} className="flex justify-between text-sm">
                  <span className="text-text-secondary">{cat.name}</span>
                  <span className="text-income font-medium tabular-nums">
                    {formatPLN(cat.gross)} zł
                  </span>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Expense breakdown */}
      {data.expenseByCategory.length > 0 && (
        <div className="bg-bg-card rounded-xl p-4 border border-border">
          <h3 className="text-sm font-semibold text-text-secondary mb-3 uppercase tracking-wide">
            Koszty wg kategorii
          </h3>
          <div className="space-y-2">
            {data.expenseByCategory
              .sort((a, b) => b.gross - a.gross)
              .map((cat) => (
                <div key={cat.name} className="flex justify-between text-sm">
                  <span className="text-text-secondary">{cat.name}</span>
                  <span className="text-expense font-medium tabular-nums">
                    {formatPLN(cat.gross)} zł
                  </span>
                </div>
              ))}
          </div>
        </div>
      )}

      {/* Fixed vs Variable */}
      <div className="bg-bg-card rounded-xl p-4 border border-border">
        <h3 className="text-sm font-semibold text-text-secondary mb-3 uppercase tracking-wide">
          Koszty stałe vs zmienne
        </h3>
        <div className="flex justify-between text-sm mb-2">
          <span className="text-text-secondary">Stałe (recurring)</span>
          <span className="font-medium tabular-nums">
            {formatPLN(data.fixedExpenses)} zł
          </span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-text-secondary">Zmienne (ręczne)</span>
          <span className="font-medium tabular-nums">
            {formatPLN(data.variableExpenses)} zł
          </span>
        </div>
      </div>
    </div>
  );
}

function KPICard({
  label,
  value,
  color,
}: {
  label: string;
  value: number;
  color: string;
}) {
  return (
    <div className="bg-bg-card rounded-xl p-4 border border-border">
      <p className="text-xs text-text-muted mb-1">{label}</p>
      <p className={`text-xl font-bold tabular-nums ${color}`}>
        {formatPLN(value)} zł
      </p>
    </div>
  );
}
