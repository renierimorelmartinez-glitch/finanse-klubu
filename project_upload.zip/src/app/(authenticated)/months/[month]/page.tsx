"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { formatMonthLabel } from "@/lib/month-utils";
import Link from "next/link";

interface MonthData {
  month: string;
  zusAmount: number;
  pitAmount: number;
  vatAdjustmentAmount: number;
  status: "OPEN" | "CLOSED";
  closedAt: string | null;
}

export default function MonthDetailPage() {
  const params = useParams();
  const router = useRouter();
  const month = params.month as string;

  const [data, setData] = useState<MonthData | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [zus, setZus] = useState("");
  const [pit, setPit] = useState("");
  const [vatAdj, setVatAdj] = useState("");

  const fetchData = async () => {
    setLoading(true);
    const res = await fetch(`/api/months/${month}`);
    const d = await res.json();
    setData({
      ...d,
      zusAmount: Number(d.zusAmount),
      pitAmount: Number(d.pitAmount),
      vatAdjustmentAmount: Number(d.vatAdjustmentAmount),
    });
    setZus(String(Number(d.zusAmount)));
    setPit(String(Number(d.pitAmount)));
    setVatAdj(String(Number(d.vatAdjustmentAmount)));
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, [month]);

  const handleSave = async () => {
    setSaving(true);
    await fetch(`/api/months/${month}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        zusAmount: parseFloat(zus) || 0,
        pitAmount: parseFloat(pit) || 0,
        vatAdjustmentAmount: parseFloat(vatAdj) || 0,
      }),
    });
    setSaving(false);
    fetchData();
  };

  const handleClose = async () => {
    if (
      !confirm(
        "Zamknąć miesiąc? Transakcje zostaną zablokowane. Możesz później otworzyć ponownie."
      )
    )
      return;

    await fetch(`/api/months/${month}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "close" }),
    });
    fetchData();
  };

  const handleReopen = async () => {
    if (!confirm("Otworzyć miesiąc ponownie?")) return;
    await fetch(`/api/months/${month}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "reopen" }),
    });
    fetchData();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 text-text-muted">
        Ładowanie...
      </div>
    );
  }

  const isClosed = data?.status === "CLOSED";

  return (
    <div className="max-w-lg mx-auto p-4 space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">{formatMonthLabel(month)}</h2>
          <span
            className={`text-xs px-2 py-0.5 rounded font-medium ${
              isClosed
                ? "bg-income/20 text-income"
                : "bg-bg-hover text-text-secondary"
            }`}
          >
            {isClosed ? "ZAMKNIĘTY" : "OTWARTY"}
          </span>
        </div>
        <Link
          href={`/dashboard?month=${month}`}
          className="text-sm text-accent hover:underline"
        >
          Dashboard
        </Link>
      </div>

      {data?.closedAt && (
        <p className="text-xs text-text-muted">
          Zamknięto: {new Date(data.closedAt).toLocaleString("pl-PL")}
        </p>
      )}

      {/* Params form */}
      <div className="bg-bg-card rounded-xl p-4 border border-border space-y-3">
        <h3 className="text-sm font-semibold text-text-secondary uppercase tracking-wide">
          Parametry miesiąca
        </h3>

        <div>
          <label className="block text-xs text-text-secondary mb-1">ZUS (zł)</label>
          <input
            type="number"
            step="0.01"
            min="0"
            value={zus}
            onChange={(e) => setZus(e.target.value)}
            disabled={isClosed}
          />
        </div>

        <div>
          <label className="block text-xs text-text-secondary mb-1">PIT (zł)</label>
          <input
            type="number"
            step="0.01"
            min="0"
            value={pit}
            onChange={(e) => setPit(e.target.value)}
            disabled={isClosed}
          />
        </div>

        <div>
          <label className="block text-xs text-text-secondary mb-1">
            Korekta VAT (zł)
          </label>
          <input
            type="number"
            step="0.01"
            value={vatAdj}
            onChange={(e) => setVatAdj(e.target.value)}
            disabled={isClosed}
          />
        </div>

        {!isClosed && (
          <button
            onClick={handleSave}
            disabled={saving}
            className="w-full py-2 bg-accent hover:bg-accent-hover text-bg-primary font-semibold rounded-lg text-sm transition-colors disabled:opacity-50"
          >
            {saving ? "Zapisuję..." : "Zapisz parametry"}
          </button>
        )}
      </div>

      {/* Close / Reopen */}
      <div className="space-y-2">
        {isClosed ? (
          <button
            onClick={handleReopen}
            className="w-full py-3 bg-warning/20 hover:bg-warning/30 text-warning font-semibold rounded-lg text-sm transition-colors"
          >
            Otwórz miesiąc ponownie
          </button>
        ) : (
          <button
            onClick={handleClose}
            className="w-full py-3 bg-expense/20 hover:bg-expense/30 text-expense font-semibold rounded-lg text-sm transition-colors"
          >
            Zamknij miesiąc
          </button>
        )}
      </div>

      <Link
        href="/months"
        className="block text-center text-sm text-text-muted hover:text-text-secondary"
      >
        Wróć do listy
      </Link>
    </div>
  );
}
