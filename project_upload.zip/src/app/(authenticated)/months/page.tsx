"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { getMonthsList, formatMonthLabel, getCurrentMonth } from "@/lib/month-utils";

interface MonthParam {
  month: string;
  status: "OPEN" | "CLOSED";
  zusAmount: string;
  pitAmount: string;
  closedAt: string | null;
}

export default function MonthsPage() {
  const [monthParams, setMonthParams] = useState<Record<string, MonthParam>>({});
  const [loading, setLoading] = useState(true);
  const months = getMonthsList(12);

  useEffect(() => {
    fetch("/api/months")
      .then((r) => r.json())
      .then((data: MonthParam[]) => {
        const map: Record<string, MonthParam> = {};
        for (const m of data) {
          map[m.month] = m;
        }
        setMonthParams(map);
        setLoading(false);
      });
  }, []);

  const currentMonth = getCurrentMonth();

  return (
    <div className="max-w-2xl mx-auto p-4 space-y-4">
      <h2 className="text-lg font-semibold">Miesiące</h2>

      {loading ? (
        <div className="text-center text-text-muted py-8">Ładowanie...</div>
      ) : (
        <div className="space-y-2">
          {months.map((month) => {
            const params = monthParams[month];
            const isClosed = params?.status === "CLOSED";
            const isCurrent = month === currentMonth;

            return (
              <Link
                key={month}
                href={`/months/${month}`}
                className="block bg-bg-card rounded-xl p-4 border border-border hover:border-border-light transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-medium text-sm">
                      {formatMonthLabel(month)}
                    </span>
                    {isCurrent && (
                      <span className="ml-2 text-xs text-accent">bieżący</span>
                    )}
                  </div>
                  <span
                    className={`text-xs px-2 py-1 rounded font-medium ${
                      isClosed
                        ? "bg-income/20 text-income"
                        : "bg-bg-hover text-text-secondary"
                    }`}
                  >
                    {isClosed ? "ZAMKNIĘTY" : "OTWARTY"}
                  </span>
                </div>
                {params && (
                  <div className="text-xs text-text-muted mt-1">
                    ZUS: {Number(params.zusAmount).toFixed(2)} · PIT:{" "}
                    {Number(params.pitAmount).toFixed(2)}
                    {params.closedAt && (
                      <span>
                        {" "}
                        · zamknięto: {new Date(params.closedAt).toLocaleDateString("pl-PL")}
                      </span>
                    )}
                  </div>
                )}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
